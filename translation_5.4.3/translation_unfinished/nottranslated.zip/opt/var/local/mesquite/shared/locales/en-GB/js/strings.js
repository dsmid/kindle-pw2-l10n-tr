Cancel	İptal#or#İptal Et
Close	İptal#or#Kapat
Connection Required	
Lock Rotation	
Register	Kaydol#or#Kayıt
Remove	
This action requires wireless to be turned on.	
Unable to Connect	Bağlanamıyor#or#Bağlantı kurulamadı
Unlock Rotation	
Your Kindle is currently unable to connect.<br><br>Please try again later.	
