Cancel	İptal#or#İptal Et
Close	İptal#or#Kapat
Connection Required	
Remove	
Screen Light	
Unable to Connect	Bağlanamıyor#or#Bağlantı kurulamadı
Your Kindle is currently unable to connect.<br><br>Please try again later.	
strings	
