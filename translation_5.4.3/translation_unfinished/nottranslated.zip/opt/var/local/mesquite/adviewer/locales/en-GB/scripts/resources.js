Close	İptal#or#Kapat
Details for this advert are no longer available. Turn on wireless to receive the latest content.	
Details for this advert are no longer available.	
Device Not Registered	
Offer Expired	
Order Cancelled	
Parental Controls are enabled on your Kindle. Purchases are not allowed.	
Please connect wirelessly to download the latest Special Offers. New offers will display automatically when available.	
Please register your Kindle to receive the latest Special Offers. New offers will display automatically when available.	
Purchase Limit Reached	
Purchased by Accident? Cancel this Order	
Purchasing Locked	
Special Offer	
Thank you for your order	
To complete your AmazonLocal order, connect to a wireless network within the next {purchaseDaysRemaining} days. We will send a voucher to the Home screen and a notification to your e-mail account once your order has processed. The voucher will contain instructions on how to redeem this offer.	
View All Special Offers	
We are unable to process your request. Please try again later.	
You already have {count} order(s) pending for this special offer.	
You have other orders pending. Click here to view	
You have successfully cancelled your order for {dealTitle} from {merchantName}. Your credit card was not charged.	
You must register your Kindle to make a purchase.	
Your order will be placed when you connect to wireless.	
Your purchase could not be completed. This offer has expired.	
Your purchase could not be completed. We are experiencing technical difficulties. Please try again later.	
Your purchase could not be completed. You have reached the maximum purchase quantity.	
{customerName}, you have nearly finished.	
