100pt	
All Text	
Baidu Baike	
Baidu	
Douban	
Google	
Kindle Store	
My Items	Benim Ürünlerim#or#Ögelerim
Web Address	
Wikipedia	
