0 {right} 0 0	
Off	
Track {index,number,integer} of {count,number,integer}	
Unknown Artists	
{width}px	
